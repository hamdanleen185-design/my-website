/* السنة في الفوتر + شريط التقدم + ظهور العناصر عند التمرير */
document.getElementById("yr").textContent=new Date().getFullYear();
var bar=document.getElementById("bar");
addEventListener("scroll",function(){var h=document.documentElement;bar.style.width=(h.scrollTop/(h.scrollHeight-h.clientHeight||1)*100)+"%"});
var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add("on");io.unobserve(x.target)}})},{threshold:.1});
document.querySelectorAll(".rv").forEach(function(e,i){e.style.transitionDelay=(i%3)*80+"ms";io.observe(e)});
