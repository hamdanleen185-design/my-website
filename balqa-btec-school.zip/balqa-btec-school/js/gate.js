/* بوابة الدخول */
var gate=document.getElementById("gate");document.body.style.overflow="hidden";
function openGate(){gate.classList.add("open");setTimeout(function(){gate.remove();document.body.style.overflow=""},1500)}
document.getElementById("enter").onclick=openGate;
document.getElementById("skip").onclick=function(){gate.remove();document.body.style.overflow=""};
